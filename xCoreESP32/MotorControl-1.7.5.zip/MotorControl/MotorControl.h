﻿#pragma once
#include <Arduino.h>

#ifndef ESP32
#error "this library is only for ESP32"
#endif

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//#define ENCODER_VESION 4
//#define ENCODER_VESION 5

//#define ENCODER_DISABLE_POL

#define ENCODER_TICKS 6
#define ENCODER_PERTICK_SCAN 2

#define ENCODER_WAIT_MIN 100
#define ENCODER_WAIT_MAX 10000

#define MOTOR_PWM_RESOLUTION 12
#define MOTOR_PWM_FREQUENCY 16000
#define MOTOR_MIN_SPEED 3
#define MOTOR_PWM_INVERSION 1

#define ACCELERATION_ENABLE
#define ACCELERATION_SPEED_STEP 3
//#define ACCELERATION_MICROS_STEP 10000
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#ifndef NC
#define NC 0xFF
#endif

class Encoder {
public:
    Encoder() {
        sample = NULL;
    }
    ~Encoder() {
        if (sample) {
            free((void *)sample);
            sample = NULL;
        }
    }
    void encoder(uint32_t pinENC_A, uint32_t pinENC_B,
                 long deltaT, int ticksPerRev, bool upend);
    int getSpeed();
    int getDistance();
    static void _encoderISR(void *arg, uint32_t micro, bool pinState);
    uint32_t _pinENC_A, _pinENC_B;

public:
    uint16_t _pwm_max;
    bool _upend;
    volatile uint32_t _timePeriod;
    volatile uint32_t _updateMicros;
    volatile int _pol;
    volatile bool _updateSpeed;
    volatile uint32_t _updateCount;
    uint32_t _updateCountMax;
    int _ticksPerRev;
    int _lastSpeed;
    volatile int _int_lastSpeed;
    volatile uint32_t *sample;
    volatile uint8_t head;
    uint8_t _encoderTick;
    double _degPerTick;
    volatile long _count, _oldCount, _newCount;
    long _deltaT;
    volatile long _totalCount;
};

class Motor {
public:
    Motor() {}

    void motor(uint32_t pinDIR, uint32_t pinSLEEP, uint32_t pinPWM, bool pwmInv, bool upend) {
        _pwmMax = (1 << MOTOR_PWM_RESOLUTION) - 1;
        _upend = upend;
        _inv = pwmInv;
        _pol = 1;
        _pinDIR = pinDIR;
        _pinSLEEP = pinSLEEP;
        _pinPWM = pinPWM;
        movement = false;
        pinMode(_pinDIR, OUTPUT);
        digitalWrite(_pinDIR, _upend ? LOW : HIGH);
        pinMode(_pinPWM, OUTPUT);
        pinMode(_pinPWM, _inv ? HIGH : LOW);       
        
        if (_pinSLEEP < GPIO_PIN_COUNT) {
            pinMode(_pinSLEEP, OUTPUT);
            digitalWrite(_pinSLEEP, HIGH);
        }      
    }

    inline void IRAM_ATTR setFwd() {
        _pol = 1;
        digitalWrite(_pinDIR, _upend ? LOW : HIGH);
        if (_pinSLEEP < GPIO_PIN_COUNT) {
            digitalWrite(_pinSLEEP, HIGH);
        }
        movement = true;
    }

    inline void IRAM_ATTR setBack() {
        _pol = -1;
        digitalWrite(_pinDIR, _upend ? HIGH : LOW);
        if (_pinSLEEP < GPIO_PIN_COUNT) {
            digitalWrite(_pinSLEEP, HIGH);
        }
        movement = true;
    }

    inline void IRAM_ATTR setFree() {
        if (_pinSLEEP < GPIO_PIN_COUNT) {
            digitalWrite(_pinSLEEP, LOW);
        }
        digitalWrite(_pinDIR, LOW);
        movement = false;
        _pwmWrite(_pinPWM, 0);
    }

    inline void IRAM_ATTR setStop() {
        digitalWrite(_pinDIR, HIGH);
        if (_pinSLEEP < GPIO_PIN_COUNT) {
            digitalWrite(_pinSLEEP, HIGH);
        }
        movement = false;
        _pwmWrite(_pinPWM, 0);
    }

    inline void IRAM_ATTR setPWM(int level) {
        _pwmWrite(_pinPWM, movement ? level : 0);
    }

    bool movement;
    int _pol = 0;
    uint32_t _pwmMax;

private:
    uint32_t _pinDIR, _pinSLEEP, _pinPWM;
    bool _inv, _upend;

    inline void IRAM_ATTR _pwmWrite(uint32_t Pin, uint32_t Value) {
        if (Value > _pwmMax) Value = _pwmMax;
        analogWrite(Pin, _inv ? _pwmMax - Value : Value);
    }
};

class SpeedControl {
public:
    SpeedControl(void) {
        speedcontrol(NULL, NULL);
        _pwm_max = (1 << MOTOR_PWM_RESOLUTION) - 1;;
    }

    void speedcontrol(Motor *motor, Encoder *encoder);
    void setGains(double kP, double kI, double kD);
    void setSpeed(int speed);
    void setMinSpeed(int minSpeed);
    int getDistance();
    int adjustPWM(void);
    volatile int _cyrrSpeed;

#ifdef ACCELERATION_ENABLE
    void refreshSpeed(void);
#endif

    int getLastSpeed(void);
    
    inline int getSpeed(void) {
        return getLastSpeed();
    }

private:
    uint32_t _pwm_max;
    volatile int _speed;
    volatile int _nextSpeed;
    volatile uint32_t _startMicros;
    volatile int _setPoint, _minSpeed, _lastSpeed;
    volatile int _pwm;
    double _iTerm, _kP, _kI, _kD;
    Motor *_motor;
    Encoder *_encoder;
};

class MotorControl {
public:
    Motor motor;
    Encoder encoder;
    SpeedControl speedControl;

    void motorcontrol(uint32_t pinPWM, uint32_t pinDIR, uint32_t pinSLEEP,
                      uint32_t pinENC_A, uint32_t pinENC_B,
                      bool pwmINV = MOTOR_PWM_INVERSION,
                      bool upend = false) {
        _upend = upend;
        _pinPWM = pinPWM;
        _pinDIR = pinDIR;
        _pinSLEEP = pinSLEEP;
        _pinENC_A = pinENC_A;
        _pinENC_B = pinENC_B;
        _pwmINV = pwmINV;
    }

    MotorControl(uint32_t pinPWM, uint32_t pinDIR, uint32_t pinSLEEP,
                 uint32_t pinENC_A, uint32_t pinENC_B,
                 bool pwmINV = MOTOR_PWM_INVERSION,
                 bool upend = false) {
        motorcontrol(pinPWM, pinDIR, pinSLEEP, pinENC_A, pinENC_B, pwmINV);
    }

    bool begin(long deltaT = 1000, int ticksPerRev = 270, double kP = 0.75, double kI = 0.0075, double kD = 4.5) {
        analogWriteResolution(MOTOR_PWM_RESOLUTION);
        analogWriteFrequency(MOTOR_PWM_FREQUENCY);
        motor.motor(_pinDIR, _pinSLEEP, _pinPWM, _pwmINV, _upend);
        encoder.encoder(_pinENC_A, _pinENC_B, deltaT, ticksPerRev, _upend);
        speedControl.speedcontrol(&motor, &encoder);
        speedControl.setGains(kP, kI, kD);
        return attachIntSysTick(_IntAdjustPWM, deltaT, this);
    }

    void  end(void) {
        detachIntSysTick(_IntAdjustPWM, this);
        detachInterrupt(_pinENC_A);
    }

    static void IRAM_ATTR _IntAdjustPWM(void *arg) {
        if (arg) {
            MotorControl *mc = (MotorControl *)arg;
			mc->speedControl.adjustPWM();          
        }
    }

private:
    uint32_t _pinPWM;
    uint32_t _pinDIR;
    uint32_t _pinSLEEP;
    uint32_t _pinENC_A;
    uint32_t _pinENC_B;
    bool _pwmINV;
    bool _upend;
};
