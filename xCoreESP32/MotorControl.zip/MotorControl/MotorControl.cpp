#include "MotorControl.h"

void Encoder::encoder(uint32_t pinENC_A, uint32_t pinENC_B, long deltaT, int ticksPerRev) {
    _pinENC_A = pinENC_A;
    _pinENC_B = pinENC_B;
    _count = 0;
    _oldCount = 0;
    _newCount = 0;
    _totalCount = 0;
    _lastSpeed = 0;
    _deltaT = deltaT;
    _updateCount = 0;
    head = 0;
    memset((void*)sample, 0, sizeof(sample));
    _pol = 1;
    _degPerTick = (double)ticksPerRev;
    pinMode(_pinENC_A, INPUT_PULLUP);
    pinMode(_pinENC_B, INPUT_PULLUP);

    _updateMicros = micros();
    _timePeriod = 0;
    _updateSpeed = false;
    _encoderTick = 12;
    _updateCountMax = (_encoderTick * ENCODER_PERTICK_SCAN) + 1;
    _updateCount = _updateCountMax;

    attachInterrupt(pinENC_A, _encoderISR, CHANGE, this);
}

int Encoder::getDistance() {
    int distance = _totalCount / _degPerTick;
    _totalCount = 0;
    return distance;
}

int Encoder::getSpeed() {
    uint32_t micro = micros();
    if ((micro > _updateMicros) && ((micro - _updateMicros) > ENCODER_WAIT_MAX)) {
        _updateCount = _updateCountMax;
        return _int_lastSpeed = 0;
    }

    if (_updateCount == _updateCountMax) {
        return _int_lastSpeed;
    }

#if (ENCODER_VESION == 4)
    uint8_t fltr = _encoderTick * ENCODER_PERTICK_SCAN;
    uint8_t start_pos = head - fltr;
    uint32_t smpl_min = ~0, smpl_max = 0;
    uint32_t ignore_min = ~0, ignore_max = 0;
    for (uint8_t i = 0, pos = start_pos; i < fltr; i++) {
        uint32_t val = sample[pos++];
        if (ignore_min > val) ignore_min = val;
        if (ignore_max < val) ignore_max = val;
    }
    for (uint8_t i = 0, pos = start_pos; i < fltr; i++) {
        uint32_t val = sample[pos++];
        if (val == ignore_min) continue;
        if (val == ignore_max) continue;
        if (smpl_min > val) smpl_min = val;
        if (smpl_max < val) smpl_max = val;
    }

    if ((smpl_min != ~0) && (smpl_max != 0)) {
        _timePeriod = smpl_min + smpl_max;
    } else {
        start_pos = head - fltr;
        _timePeriod = sample[start_pos++] + sample[start_pos];
    }
#elif (ENCODER_VESION == 5)
    uint8_t fltr = _encoderTick;
    uint8_t start_pos = head - fltr;
    double acc = 0;
    for (uint8_t i = 0, pos = start_pos; i < fltr; i++) {
        acc += sample[start_pos++];
    }
    acc /= _encoderTick / 2;
    _timePeriod = acc;
#else
    uint8_t fltr = _encoderTick * ENCODER_PERTICK_SCAN;
    uint8_t start_pos = head - fltr;
    double acc = 0;
    for (uint8_t i = 0, pos = start_pos; i < fltr; i++) {
        acc += sample[start_pos++];
    }
    acc /= _encoderTick;
    _timePeriod = acc;
#endif

    if (_timePeriod > ENCODER_WAIT_MIN) {
        double degPerSec = 1000000.0;
        degPerSec /= _timePeriod;
#ifdef ENCODER_ENABLE_T12
        degPerSec /= _encoderTick;
#else
        degPerSec /= _degPerTick;
#endif
        degPerSec *= 60;
        _int_lastSpeed = degPerSec * _pol;
    }

    return _int_lastSpeed;
}

void Encoder::_encoderISR(void* arg, uint32_t micro, bool pinState) {
    Encoder* _this = (Encoder*)arg;

    _this->sample[_this->head++] = micro;

    if (pinState == HIGH) {
#ifndef ENCODER_DISABLE_POL
        _this->_pol = digitalRead(_this->_pinENC_B) ? -1 : 1;
#endif
        _this->_totalCount += 1;
    }

    _this->_updateMicros = micros();
    if (_this->_updateCount) {
        uint8_t fltr = _this->_updateCount;
        uint8_t start_pos = _this->head - fltr;
        for (uint8_t i = 0, pos = start_pos; i < fltr; i++) {
            _this->sample[pos++] = micro;
        }
        _this->_updateCount -= 1;
    }
}

const double defaultGain = 1.0;

void SpeedControl::speedcontrol(Motor* motor, Encoder* encoder) {
    _encoder = encoder;
    _motor = motor;
    _iTerm = 0;
    _pwm = 0;
    _lastSpeed = 0;
    _kP = defaultGain;
    _kI = defaultGain;
    _kD = defaultGain;
    _setPoint = 0;
    _cyrrSpeed = 0;
    _nextSpeed = 0;
    _minSpeed = MOTOR_MIN_SPEED;
    _startMicros = micros();
}

void SpeedControl::setGains(double kP, double kI, double kD) {
    _kP = kP;
    _kI = kI;
    _kD = kD;
}

void SpeedControl::setMinSpeed(int minSpeed) {
    _minSpeed = minSpeed;
}

#ifndef ACCELERATION_ENABLE
void SpeedControl::setSpeed(int speed) {
    if (_motor == NULL) return;
    _motor->setFwd();
    if (speed < 0) {
        _motor->setBack();
        speed *= -1;
    } else if (speed > 0) {
        _motor->setFwd();
    }
    if (speed == 0) {
        _motor->setFree();
    }
    if (speed < _minSpeed && speed > 0)
        speed = _minSpeed;
    _setPoint = speed;
}
#endif

#ifdef ACCELERATION_ENABLE
void SpeedControl::setSpeed(int speed) {
    _nextSpeed = speed;
}

void SpeedControl::refreshSpeed(void) {
    if (_motor == NULL) return;
#ifdef ACCELERATION_MICROS_STEP
    register uint32_t _cyrrMicros = micros();
    if ((_cyrrMicros - _startMicros) < ACCELERATION_MICROS_STEP) return;
    _startMicros = _cyrrMicros;
#endif

    if (_cyrrSpeed == _nextSpeed) return;

    for (int ftmp = 0; ftmp < ACCELERATION_SPEED_STEP; ftmp++) {
        if (_nextSpeed > _cyrrSpeed) {
            if (++_cyrrSpeed == _nextSpeed) break;
        }

        if (_nextSpeed < _cyrrSpeed) {
            if (--_cyrrSpeed == _nextSpeed) break;
        }
    }

    int speed = _cyrrSpeed;

    if (speed < 0) {
        _motor->setBack();
        speed *= -1;
    } else if (speed > 0) {
        _motor->setFwd();
    }
    if (speed == 0) {
        _motor->setFree();
    }
    if (speed < _minSpeed && speed > 0)
        speed = _minSpeed;
    _setPoint = speed;
}
#endif

int SpeedControl::getDistance() {
    if (_encoder == NULL) return 0;
    return _encoder->getDistance();
}

#ifdef ENCODER_ENABLE_T12
int SpeedControl::getLastSpeed(void) {
    return (_speed * _encoder->_encoderTick) / _encoder->_degPerTick;
}

int SpeedControl::adjustPWM() {
    if ((_motor == NULL) || (_encoder == NULL)) return 0;
#ifdef ACCELERATION_ENABLE
    refreshSpeed();
#endif
    _speed = _encoder->getSpeed();
#ifdef ENCODER_DISABLE_POL
    _speed *= _motor->_pol;
#endif
    int speed = abs(_speed);
    int setPoint = _setPoint * (_encoder->_degPerTick / _encoder->_encoderTick);
    int error = setPoint - speed;
    if (error != 0) {
#if (SPEEDCONTROL_VESION == 2)
        double dP = 1.0 + ((((double)min(setPoint, speed)) / ((double)max(setPoint, speed))) * 3);
        uint16_t pwm_max = analogWrite_GetPeriod() + 1;
        _iTerm += (_kI * (double)error);
        double dInput = speed - abs(_lastSpeed);
        int adjustment = (_kP * (double)error) * dP + _iTerm - (_kD * dInput) * dP;
        _iTerm = constrain(_iTerm, 0, SPEEDCONTROL_I_MAX);
        _pwm = constrain(adjustment, 0, SPEEDCONTROL_OUT_MAX);
        _motor->setPWM(_map(_pwm, 0, SPEEDCONTROL_OUT_MAX, 0, pwm_max));
#else
        uint16_t pwm_max = analogWrite_GetPeriod() + 1;
        _iTerm += (_kI * (double)error);
        _iTerm = constrain(_iTerm, -SPEEDCONTROL_I_MAX, SPEEDCONTROL_I_MAX);
        double dInput = speed - abs(_lastSpeed);
        int adjustment = (_kP * (double)error) + _iTerm - (_kD * dInput);
        _pwm = constrain(adjustment, 0, SPEEDCONTROL_OUT_MAX);
        _motor->setPWM(map(_pwm, 0, SPEEDCONTROL_OUT_MAX, 0, pwm_max));
#endif
    }
    _lastSpeed = _speed;
    return _lastSpeed;
}

#else

int SpeedControl::getLastSpeed(void) {
    return _speed;
}

int SpeedControl::adjustPWM() {
    if ((_motor == NULL) || (_encoder == NULL)) return 0;
#ifdef ACCELERATION_ENABLE
    refreshSpeed();
#endif
    _speed = _encoder->getSpeed();
    int speed = abs(_speed);
    int error = _setPoint - speed;
    if (error != 0) {
        error *= 4;
        uint16_t pwm_max = analogWrite_GetPeriod() + 1;
        _iTerm += (_kI * (double)error);
        _iTerm = constrain(_iTerm, -SPEEDCONTROL_I_MAX, SPEEDCONTROL_I_MAX);
        double dInput = speed - abs(_lastSpeed);
        int adjustment = (_kP * (double)error) + _iTerm - (_kD * dInput);
        _pwm = constrain(adjustment, 0, SPEEDCONTROL_OUT_MAX);
        _motor->setPWM(map(_pwm, 0, SPEEDCONTROL_OUT_MAX, 0, pwm_max));
    }
    _cyrrSpeed = _speed;
    _lastSpeed = _speed;
    return _lastSpeed;
}
#endif
